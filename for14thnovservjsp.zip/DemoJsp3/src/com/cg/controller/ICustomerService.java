package com.cg.controller;

import java.util.ArrayList;

public interface ICustomerService {

	public boolean addCustomer(CustomerBean cust);
	public ArrayList<CustomerBean> viewAllCustomer();
	
}
