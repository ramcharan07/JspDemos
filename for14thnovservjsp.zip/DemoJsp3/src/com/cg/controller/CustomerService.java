package com.cg.controller;

import java.util.ArrayList;

public class CustomerService implements ICustomerService {

	ArrayList<CustomerBean> custList  = new ArrayList<CustomerBean>();
	@Override
	public boolean addCustomer(CustomerBean cust) {
		boolean status = false;
		status = custList.add(cust);
	//	custList.stream().forEach(System.out::println);
		//System.out.println("list : " + custList.size());
		return status;
	}
	@Override
	public ArrayList<CustomerBean> viewAllCustomer() {
		System.out.println(custList);
		return custList;
	}

}
