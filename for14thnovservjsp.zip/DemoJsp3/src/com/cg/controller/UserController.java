package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserController
 */
@WebServlet({"/user.do","viewall"})
public class UserController extends HttpServlet {

	ICustomerService serv=new CustomerService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String path=req.getServletPath();
		switch(path){
		case "/user.do":
		//get data from form
		
		String n=req.getParameter("name");
		int a=Integer.parseInt(req.getParameter("age"));
		String city=req.getParameter("city");
		int p=Integer.parseInt(req.getParameter("pin"));
		//store in bean obj
		CustomerBean cust=new CustomerBean(n, a, city, p);
		//arraylist -service
		//serv=new CustomerService();
		boolean storedStatus=serv.addCustomer(cust);
		
		if(storedStatus){
			req.setAttribute("custObj", cust);
			req.setAttribute("msg", "successfully stored!!!");
		req.getRequestDispatcher("success").forward(req, resp);	
		}
		else{
			req.setAttribute("msg", "data not stored");
			req.getRequestDispatcher("index.jsp").forward(req, resp);
			
		}
		break;
		case "/viewall":
			ArrayList<CustomerBean> list=serv.viewAllCustomer();
			//System.out.println("in ctlr "+list);
			req.setAttribute("cList",list);
			req.getRequestDispatcher("viewall.jsp").forward(req, resp);
			
			break;
	}
	}
		

}