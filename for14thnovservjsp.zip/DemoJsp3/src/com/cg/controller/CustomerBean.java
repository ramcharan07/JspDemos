package com.cg.controller;

public class CustomerBean {

	private String name;
	private int age;
	private String city;
	private int pin;
	
	public void display(){
		System.out.println("in display");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public CustomerBean() {
		// TODO Auto-generated constructor stub
	}
	public CustomerBean(String name, int age, String city, int pin) {
		super();
		this.name = name;
		this.age = age;
		this.city = city;
		this.pin = pin;
	}
	
	/*@Override
	public String toString() {
	return this.name+" "+this.city+" "+this.age+" "+this.pin;
	
	}*/
}
